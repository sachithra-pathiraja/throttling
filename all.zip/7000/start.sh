nohup redis-server 7000.conf &
