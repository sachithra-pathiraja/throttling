nohup redis-server 7001.conf &
