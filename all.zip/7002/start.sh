nohup redis-server 7002.conf &
