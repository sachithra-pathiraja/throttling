nohup redis-server 7004.conf &
